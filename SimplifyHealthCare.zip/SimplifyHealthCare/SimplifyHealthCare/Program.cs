﻿using System;
namespace SimplifyHealthCare
{
    class Program
    {
        static int[] input;
        static int[] rowExist;

        static void Main(string[] args)
        {
             input = new int[] { 2, 4, 6, 1, 3, 5 }; //true
            // input = new int[] { 4, 2, 1, 6, 5, 3 }; // false
            // input = new int[] { 4, 1, 5, 6, 2, 3 }; //false
            // input = new int[] { 4, 1, 5, 2, 6,3}; //true
            // input = new int[] { 3, 4, 2, 1, 6, 5 };//false
            GenerateMatrix(input);
        }

        static void GenerateMatrix(int[] input)
        {
            int[,] matrix = new int[input.Length, input.Length];
            rowExist = new int[input.Length];
            bool result = BuildMatrix(matrix, 0);
            Console.WriteLine("\n");
            Console.WriteLine("Result : " + result);
            Console.WriteLine("\n");
            Console.WriteLine("---Matrix---\n");
            PrintMatrix(matrix);
            Console.Read();
        }


        static bool BuildMatrix(int[,] matrix, int column)
        {
            if (column >= input.Length) return true;
            for (int i = 0; i < input.Length; i++)
            {
                if (!Array.Exists(rowExist, element => element == input[i]))
                {
                    rowExist[i] = input[i];
                    int rowIndex = input[i];
                    if (IsMatrixValueValid(matrix, rowIndex - 1, column))
                    {
                        matrix[rowIndex - 1, column] = 1;
                        if (BuildMatrix(matrix, column + 1)) return true;
                    }
                    else
                    {
                        matrix[rowIndex - 1, column] = 1;
                        BuildMatrix(matrix, column + 1);
                    }
                }
            }
            return false;
        }

        static bool IsMatrixValueValid(int[,] matrix, int rowPosition, int columnPosition)
        {
            int rowIndex, columnIndex;
            for (rowIndex = 0; rowIndex < columnPosition; rowIndex++)
            {
                if (matrix[rowPosition, rowIndex] == 1)
                    return false;
            }
            for (rowIndex = rowPosition, columnIndex = columnPosition; rowIndex >= 0 && columnIndex >= 0; rowIndex--, columnIndex--)
            {
                if (matrix[rowIndex, columnIndex] == 1)
                    return false;
            }
            for (rowIndex = rowPosition, columnIndex = columnPosition; columnIndex >= 0 && rowIndex < Convert.ToInt32(Math.Sqrt(Convert.ToDouble(matrix.Length))); rowIndex++, columnIndex--)
            {
                if (matrix[rowIndex, columnIndex] == 1)
                    return false;
            }
            return true;
        }

        static void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < Convert.ToInt32(Math.Sqrt(Convert.ToDouble(matrix.Length))); i++)
            {
                for (int j = 0; j < Convert.ToInt32(Math.Sqrt(Convert.ToDouble(matrix.Length))); j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.Write("\n");
            }
        }
    }
}